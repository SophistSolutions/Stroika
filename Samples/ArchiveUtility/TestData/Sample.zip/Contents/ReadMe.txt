Sample files for Stroika's ArchiveUtility sample, which the release regression runs list (Build/Scripts/RegressionTests).
