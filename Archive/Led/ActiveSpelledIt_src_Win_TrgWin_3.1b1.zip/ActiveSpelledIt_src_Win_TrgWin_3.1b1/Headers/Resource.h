/* Copyright(c) Sophist Solutions, Inc. 1994-2001.  All rights reserved */

/*
 * $Header: \\\\Pythagoras\\Led\\CVSRoot/ActiveSpelledIt/Headers/Resource.h,v 1.2 2003/06/10 16:30:31 lewis Exp $
 */

/*
 * Changes:
 *	$Log: Resource.h,v $
 *	Revision 1.2  2003/06/10 16:30:31  lewis
 *	*** empty log message ***
 *	
 *
 *
 *
 */

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ActiveSpelledIt.rc
//
#define IDS_PROJNAME                    100
#define IDR_ACTIVESPELLEDIT             101
#define IDB_ACTIVESPELLEDITCTL          102
#define IDR_ACTIVESPELLEDITCTL          103
//#define IDR_ACTIVESPELLEDIT_SCANCONTEXT 104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
