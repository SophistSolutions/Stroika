This is VERY basic plugin example which does not use
any Java, only native Windows events.

To see it in action copy the DLL to the Plugin directory
and drag-and-drop any file with .bas extention to the Navigator
window. The plugin will create a window with a button on it.
