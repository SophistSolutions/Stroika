#define DEBUG
#define IMPLEMENT_TimeMediaPlugin


#include "TimeMediaPlugin.c"
#include "netscape_plugin_Plugin.c"