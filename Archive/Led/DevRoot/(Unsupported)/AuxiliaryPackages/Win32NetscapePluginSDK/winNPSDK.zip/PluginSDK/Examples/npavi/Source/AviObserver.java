
// java interface for events coming from the avi plugin 
// any object implementing this interface may register itself into the 
// AviPlayer to get notifications (see advise function in AviPlayer)

interface AviObserver {

	public void onStop();
	public void onPositionChange(int newPosition);

}