
// menu strings
#define MENU_PLAY               100
#define MENU_PAUSE              101
#define MENU_REWIND             102
#define MENU_FORWARD            103
#define MENU_FRAME_BACK         104
#define MENU_FRAME_FORWARD      105

// mci error strings
#define MCI_ERROR_OPEN          200
#define MCI_ERROR_PLAY          201
