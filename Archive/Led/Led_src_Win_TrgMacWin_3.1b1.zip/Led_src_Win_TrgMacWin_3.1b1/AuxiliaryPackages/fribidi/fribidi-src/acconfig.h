
#undef DEBUG

#undef MEM_OPTIMIZED

#undef USE_SIMPLE_MALLOC

#undef FRIBIDI_NO_CHARSETS

/* Check for fribidi_tab_char_type_*.i files */
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_2_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_3_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_4_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_5_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_6_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_7_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_8_I
#undef HAS_FRIBIDI_TAB_CHAR_TYPE_9_I
/* We should #undef this symbol, to make autoheader shut up */
#undef HAS_FRIBIDI_TAB_CHAR_TYPE__I
