/* Copyright(c) Sophist Solutions, Inc. 1994-2001.  All rights reserved */

/*
 * $Header: \\\\Pythagoras\\Led\\CVSRoot/LedTestWin32/Sources/StdAfx.cpp,v 1.4 2002/05/06 21:36:37 lewis Exp $
 *
 * Description:
 *
 *
 * Changes:
 *	$Log: StdAfx.cpp,v $
 *	Revision 1.4  2002/05/06 21:36:37  lewis
 *	<=============================== Led 3.0.1 Released ==============================>
 *	
 *	Revision 1.3  2001/11/27 00:33:30  lewis
 *	<=============== Led 3.0 Released ===============>
 *	
 *	Revision 1.2  2001/08/30 01:09:23  lewis
 *	*** empty log message ***
 *	
 *	Revision 1.1  1999/11/15 22:17:00  lewis
 *	Initial revision
 *	
 *
 *
 */


#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
