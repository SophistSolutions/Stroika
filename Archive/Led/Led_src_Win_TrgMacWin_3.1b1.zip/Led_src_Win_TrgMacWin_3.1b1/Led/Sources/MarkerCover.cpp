/* Copyright(c) Sophist Solutions, Inc. 1994-2001.  All rights reserved */

/*
 * $Header: \\\\Pythagoras\\Led\\CVSRoot/Led/Sources/MarkerCover.cpp,v 2.6 2002/05/06 21:33:48 lewis Exp $
 *
 * Changes:
 *	$Log: MarkerCover.cpp,v $
 *	Revision 2.6  2002/05/06 21:33:48  lewis
 *	<=============================== Led 3.0.1 Released ==============================>
 *	
 *	Revision 2.5  2001/11/27 00:29:54  lewis
 *	<=============== Led 3.0 Released ===============>
 *	
 *	Revision 2.4  2001/08/28 18:43:37  lewis
 *	*** empty log message ***
 *	
 *	Revision 2.3  1999/11/13 16:32:22  lewis
 *	<===== Led 2.3 Released =====>
 *	
 *	Revision 2.2  1999/05/03 22:05:11  lewis
 *	Misc cosmetic cleanups
 *	
 *	Revision 2.1  1997/12/24 04:40:13  lewis
 *	*** empty log message ***
 *	
 *	Revision 2.0  1997/09/29  15:06:08  lewis
 *	*** empty log message ***
 *
 *
 *
 *
 */
#if		qIncludePrefixFile
	#include	"stdafx.h"
#endif

#include	"MarkerCover.h"







// For gnuemacs:
// Local Variables: ***
// mode:c++ ***
// tab-width:4 ***
// End: ***
