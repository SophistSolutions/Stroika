/* Copyright(c) Sophist Solutions, Inc. 1994-2001.  All rights reserved */

/*
 * $Header: \\\\Pythagoras\\Led\\CVSRoot/Led/Sources/Led_ATL.cpp,v 2.1 2003/06/10 14:27:51 lewis Exp $
 *
 * Changes:
 *	$Log: Led_ATL.cpp,v $
 *	Revision 2.1  2003/06/10 14:27:51  lewis
 *	SPR#1526: as part of adding ATL-based ActiveSpelledIt - created helper file for Led/ATL
 *	
 *
 *
 *
 */
#if		qIncludePrefixFile
	#include	"stdafx.h"
#endif

#include	"Led_ATL.h"




#if		qLedUsesNamespaces
	namespace	Led {
#endif






#if		qLedUsesNamespaces
}
#endif




// For gnuemacs:
// Local Variables: ***
// mode:c++ ***
// tab-width:4 ***
// End: ***


