/* Copyright(c) Sophist Solutions, Inc. 1994-2001.  All rights reserved */

/*
 * $Header: \\\\Pythagoras\\Led\\CVSRoot/Led/Sources/Led_MacOS.cpp,v 2.4 2002/05/06 21:33:46 lewis Exp $
 *
 * Changes:
 *	$Log: Led_MacOS.cpp,v $
 *	Revision 2.4  2002/05/06 21:33:46  lewis
 *	<=============================== Led 3.0.1 Released ==============================>
 *	
 *	Revision 2.3  2001/11/27 00:29:53  lewis
 *	<=============== Led 3.0 Released ===============>
 *	
 *	Revision 2.2  2001/08/28 18:43:36  lewis
 *	*** empty log message ***
 *	
 *	Revision 2.1  2000/09/22 21:35:34  lewis
 *	*** empty log message ***
 *	
 *
 *
 *
 *
 */
#if		qIncludePrefixFile
	#include	"stdafx.h"
#endif


#include	"Led_MacOS.h"





#if		qLedUsesNamespaces
namespace	Led {
#endif






#if		qLedUsesNamespaces
}
#endif




// For gnuemacs:
// Local Variables: ***
// mode:c++ ***
// tab-width:4 ***
// End: ***
