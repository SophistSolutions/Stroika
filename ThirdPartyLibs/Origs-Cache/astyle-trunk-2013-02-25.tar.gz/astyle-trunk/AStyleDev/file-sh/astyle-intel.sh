bindir=../build/cb-intel/bin

$bindir/astyle  -taOP  "../test-c/*.cpp"  "../test-c/*.h"
