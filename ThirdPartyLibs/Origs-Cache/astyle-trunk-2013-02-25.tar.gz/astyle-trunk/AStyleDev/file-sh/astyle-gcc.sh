bindir=../build/cb-gcc/bin

$bindir/astyle  -taOP  "../test-c/*.cpp"  "../test-c/*.h"
