# build the mac executables

cd  $HOME/Projects/AStyle/build/mac
make all
