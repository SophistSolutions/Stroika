#!/bin/bash
# build astyled

#asdir=$HOME/Projects/AStyle/build/intel
asdir=$HOME/Projects/AStyle/build/gcc

cd $asdir

make  astyled


