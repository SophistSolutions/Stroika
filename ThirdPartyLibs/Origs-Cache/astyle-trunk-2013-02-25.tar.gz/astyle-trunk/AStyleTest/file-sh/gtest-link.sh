# link gtest to version directory

gtdir=gtest-1.5.0

#link to version directory 
cd ../../
sudo  ln  --force --symbolic --verbose  $HOME/Projects/$gtdir   $HOME/Projects/gtest
